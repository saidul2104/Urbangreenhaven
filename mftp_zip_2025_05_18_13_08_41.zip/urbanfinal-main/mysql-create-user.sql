-- SQL script to create a new MySQL user with privileges for urban_green_haven database

CREATE USER 'urban_user'@'localhost' IDENTIFIED BY '123';

GRANT ALL PRIVILEGES ON urban_green_haven.* TO 'urban_user'@'localhost';

FLUSH PRIVILEGES;
