-- Create the blog_posts table
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    author VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample blog posts
INSERT INTO blog_posts (title, content, image_url, author, category) VALUES
(
    'Sky High Harvest: How Rooftop Gardening is Redefining Urban Life in Bangladesh',
    '<p>In the bustling chaos of Bangladesh\'s urban sprawl, a quiet revolution is taking root above our heads. Rooftop gardening, once an eccentric hobby, has become a full-blown urban movement. Especially in cities like Dhaka and Chattogram, where concrete suffocates natural greenery, more and more citizens are transforming their rooftops into vibrant ecosystems.</p>

    <h2>The Rise of Urban Agriculture</h2>
    <p>With limited ground space and increasing population density, Bangladeshis are looking up for solutions. Rooftop gardens are not just about growing food; they\'re about creating sustainable urban ecosystems. These green spaces help combat air pollution, reduce urban heat islands, and provide fresh produce for families.</p>

    <h2>Environmental Impact</h2>
    <p>The environmental benefits are substantial. A single rooftop garden can:</p>
    <ul>
        <li>Absorb up to 50% of rainwater runoff</li>
        <li>Reduce indoor temperatures by 3-4 degrees Celsius</li>
        <li>Filter air pollutants and produce oxygen</li>
        <li>Create habitats for urban wildlife</li>
    </ul>

    <h2>Community Building</h2>
    <p>Beyond environmental benefits, rooftop gardens are fostering community connections. Neighbors share seeds, exchange gardening tips, and celebrate harvests together. In a city where social isolation is common, these green spaces are becoming vital community hubs.</p>

    <h2>Economic Benefits</h2>
    <p>For many families, rooftop gardens are more than just a hobby. They\'re a source of fresh, organic produce that reduces grocery bills and provides additional income through surplus sales. Some enterprising gardeners have even turned their rooftops into small-scale commercial operations.</p>

    <h2>Looking Forward</h2>
    <p>The future of urban agriculture in Bangladesh looks promising. With increasing awareness about food security and environmental sustainability, rooftop gardening is set to become an integral part of urban living. As more people join this green revolution, our cities will become healthier, more sustainable, and more livable.</p>',
    'blognew.jpeg',
    'Gardening Expert',
    'Urban Farming'
),
(
    'From Concrete to Green: A Beginner\'s Guide to Rooftop Gardening in Dhaka',
    '<p>Starting a rooftop garden in Dhaka might sound complicated, but it\'s easier than you think. With just a few pots, soil, and determination, you can convert your rooftop into a lush paradise.</p>

    <h2>Getting Started</h2>
    <p>Before you begin, assess your rooftop\'s capacity and access to sunlight. Most vegetables need at least 6 hours of direct sunlight daily. Check your building\'s structural capacity and ensure proper drainage.</p>

    <h2>Essential Equipment</h2>
    <ul>
        <li>Containers (pots, grow bags, or raised beds)</li>
        <li>Quality potting soil</li>
        <li>Basic gardening tools</li>
        <li>Watering system</li>
        <li>Organic fertilizers</li>
    </ul>

    <h2>Best Plants for Beginners</h2>
    <p>Start with these easy-to-grow plants:</p>
    <ul>
        <li>Tomatoes</li>
        <li>Chili peppers</li>
        <li>Eggplants</li>
        <li>Leafy greens</li>
        <li>Herbs (mint, coriander, basil)</li>
    </ul>

    <h2>Maintenance Tips</h2>
    <p>Regular care is essential for a thriving garden:</p>
    <ul>
        <li>Water plants early morning or evening</li>
        <li>Check for pests regularly</li>
        <li>Prune and harvest regularly</li>
        <li>Rotate crops seasonally</li>
    </ul>',
    'images/blog/beginners-guide-rooftop.jpg',
    'Urban Gardening Specialist',
    'Gardening Tips'
),
(
    'Balcony to Bounty: Women Leading the Rooftop Garden Revolution in Bangladesh',
    '<p>Behind the rise of rooftop gardening in Bangladesh, there\'s a powerful, green-fingered force: women. From stay-at-home mothers to retired professionals, women are turning rooftops into productive gardens.</p>

    <h2>Women\'s Role in Urban Agriculture</h2>
    <p>Women have been at the forefront of the rooftop gardening movement, bringing their traditional knowledge and innovative approaches to urban farming. Their contributions extend beyond growing food to creating sustainable communities.</p>

    <h2>Success Stories</h2>
    <p>Meet some inspiring women who have transformed their rooftops:</p>
    <ul>
        <li>Fatima Begum: Turned her 500 sq ft rooftop into a profitable organic farm</li>
        <li>Nusrat Jahan: Created a community garden that feeds 20 families</li>
        <li>Sabina Yasmin: Developed innovative vertical gardening techniques</li>
    </ul>

    <h2>Economic Empowerment</h2>
    <p>Rooftop gardening has become a source of income for many women, enabling them to contribute to their household economy while maintaining their traditional roles.</p>',
    'images/blog/women-rooftop-gardeners.jpg',
    'Community Development Expert',
    'Urban Farming'
),
(
    'Green vs. Grey: Why Every Bangladeshi Home Needs a Rooftop Garden Now',
    '<p>Urban Bangladesh is heating up — literally. The dense concrete infrastructure traps heat, worsens air quality, and increases energy consumption. But there\'s a green solution right above our heads.</p>

    <h2>Environmental Benefits</h2>
    <p>Rooftop gardens can significantly improve urban environments:</p>
    <ul>
        <li>Reduce urban heat island effect</li>
        <li>Improve air quality</li>
        <li>Manage stormwater runoff</li>
        <li>Increase biodiversity</li>
    </ul>

    <h2>Health Benefits</h2>
    <p>Beyond environmental impact, rooftop gardens offer numerous health benefits:</p>
    <ul>
        <li>Access to fresh, organic produce</li>
        <li>Reduced stress and improved mental health</li>
        <li>Physical activity through gardening</li>
        <li>Better air quality for respiratory health</li>
    </ul>',
    'images/blog/green-vs-grey.jpg',
    'Environmental Scientist',
    'Environmental Benefits'
),
(
    'Urban Farmers of Tomorrow: How Students & Youths are Cultivating Change on Rooftops',
    '<p>In the age of TikTok and Instagram, you\'d expect Gen Z to be lost in screens. But in Bangladesh, a new trend is blooming: young people are becoming urban farmers.</p>

    <h2>Youth Engagement</h2>
    <p>Young people are bringing innovation to urban farming:</p>
    <ul>
        <li>Using technology for garden management</li>
        <li>Creating social media communities</li>
        <li>Developing sustainable farming techniques</li>
        <li>Organizing community workshops</li>
    </ul>

    <h2>Educational Impact</h2>
    <p>Schools and universities are incorporating rooftop gardening into their curriculum, teaching students about:</p>
    <ul>
        <li>Sustainable agriculture</li>
        <li>Environmental science</li>
        <li>Food security</li>
        <li>Community development</li>
    </ul>',
    'images/blog/youth-urban-farmers.jpg',
    'Youth Development Specialist',
    'Urban Farming'
); 