<?php
session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log the incoming request
error_log('Consultation request received: ' . print_r($_POST, true));

// Check if config file exists
if (!file_exists('config.php')) {
    error_log('Config file not found');
    echo json_encode([
        'success' => false,
        'message' => 'Server configuration error. Please contact support.'
    ]);
    exit;
}

require_once 'config.php';

// Check if database constants are defined
if (!defined('DB_DSN') || !defined('DB_USER') || !defined('DB_PASS')) {
    error_log('Database configuration missing');
    echo json_encode([
        'success' => false,
        'message' => 'Server configuration error. Please contact support.'
    ]);
    exit;
}

// Validate required fields
$required_fields = [
    'name', 'email', 'phone', 'address', 'selected_type', 
    'consultation_date', 'consultation_time', 'payment_method', 
    'transaction_number', 'selected_price'
];

$missing_fields = [];
foreach ($required_fields as $field) {
    if (!isset($_POST[$field]) || empty($_POST[$field])) {
        $missing_fields[] = $field;
    }
}

if (!empty($missing_fields)) {
    error_log('Missing fields: ' . implode(', ', $missing_fields));
    echo json_encode([
        'success' => false, 
        'message' => 'Please fill in all required fields: ' . implode(', ', $missing_fields)
    ]);
    exit;
}

// Validate email format
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    error_log('Invalid email format: ' . $_POST['email']);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address']);
    exit;
}

// Validate phone number (basic validation)
if (!preg_match('/^[0-9+\-\s()]{10,}$/', $_POST['phone'])) {
    error_log('Invalid phone format: ' . $_POST['phone']);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid phone number']);
    exit;
}

// Validate date format
$date = DateTime::createFromFormat('Y-m-d', $_POST['consultation_date']);
if (!$date || $date->format('Y-m-d') !== $_POST['consultation_date']) {
    error_log('Invalid date format: ' . $_POST['consultation_date']);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid date']);
    exit;
}

// Validate time format
$time = DateTime::createFromFormat('H:i', $_POST['consultation_time']);
if (!$time || $time->format('H:i') !== $_POST['consultation_time']) {
    error_log('Invalid time format: ' . $_POST['consultation_time']);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid time']);
    exit;
}

try {
    // Test database connection
    error_log('Attempting database connection with DSN: ' . DB_DSN);
    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log('Database connection successful');

    // Check if table exists
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'consultation_requests'");
    if ($tableCheck->rowCount() == 0) {
        // Create the table if it doesn't exist
        $createTableSQL = "CREATE TABLE IF NOT EXISTS `consultation_requests` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) DEFAULT NULL,
            `name` varchar(255) NOT NULL,
            `email` varchar(255) NOT NULL,
            `phone` varchar(50) NOT NULL,
            `address` text NOT NULL,
            `consultation_type` varchar(50) NOT NULL,
            `consultation_date` date NOT NULL,
            `consultation_time` time NOT NULL,
            `payment_method` varchar(50) NOT NULL,
            `transaction_number` varchar(100) NOT NULL,
            `notes` text,
            `status` varchar(20) NOT NULL DEFAULT 'pending',
            `price` decimal(10,2) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        $pdo->exec($createTableSQL);
        error_log('Created consultation_requests table');
    } else {
        // If table exists, modify it to remove foreign key constraint and make user_id nullable
        try {
            $pdo->exec("ALTER TABLE consultation_requests 
                       DROP FOREIGN KEY IF EXISTS consultation_requests_ibfk_1,
                       MODIFY user_id int(11) DEFAULT NULL");
            error_log('Modified consultation_requests table structure');
        } catch (PDOException $e) {
            error_log('Error modifying table: ' . $e->getMessage());
        }
    }

    // Prepare the data for insertion
    $insertData = [
        'user_id' => null,  // Set user_id to null since we're not requiring login
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'address' => $_POST['address'],
        'consultation_type' => $_POST['selected_type'],
        'consultation_date' => $_POST['consultation_date'],
        'consultation_time' => $_POST['consultation_time'],
        'payment_method' => $_POST['payment_method'],
        'transaction_number' => $_POST['transaction_number'],
        'notes' => $_POST['notes'] ?? '',
        'status' => 'pending',
        'price' => $_POST['selected_price']
    ];

    error_log('Attempting to insert consultation request with data: ' . print_r($insertData, true));

    // Insert consultation request
    $stmt = $pdo->prepare('
        INSERT INTO consultation_requests (
            user_id,
            name,
            email,
            phone,
            address,
            consultation_type,
            consultation_date,
            consultation_time,
            payment_method,
            transaction_number,
            notes,
            status,
            price
        ) VALUES (
            :user_id,
            :name,
            :email,
            :phone,
            :address,
            :consultation_type,
            :consultation_date,
            :consultation_time,
            :payment_method,
            :transaction_number,
            :notes,
            :status,
            :price
        )
    ');

    $result = $stmt->execute($insertData);

    if ($result) {
        error_log('Consultation request inserted successfully');
        echo json_encode([
            'success' => true,
            'message' => 'Consultation request submitted successfully! We will contact you shortly.'
        ]);
    } else {
        error_log('Failed to insert consultation request');
        echo json_encode([
            'success' => false,
            'message' => 'Failed to submit consultation request'
        ]);
    }

} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    error_log('SQL State: ' . $e->getCode());
    error_log('Error Info: ' . print_r($e->errorInfo, true));
    
    // Check for specific database errors
    if ($e->getCode() == 1045) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection error. Please contact support.'
        ]);
    } else if ($e->getCode() == '42S02') {
        echo json_encode([
            'success' => false,
            'message' => 'Database configuration error. Please contact support.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}
?> 