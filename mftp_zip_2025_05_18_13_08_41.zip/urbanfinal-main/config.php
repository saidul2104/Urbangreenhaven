<?php
// Database configuration
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'urban_green_haven');
define('DB_USER', 'urban_user');
define('DB_PASS', '123'); // Updated to new user credentials

define('DB_DSN', 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4');
?>