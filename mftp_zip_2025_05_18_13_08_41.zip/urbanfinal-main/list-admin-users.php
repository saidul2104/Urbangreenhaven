<?php
require_once 'config.php';

try {
    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT id, name, email FROM users WHERE is_admin = 1");
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Admin Users</title>
</head>

<body>
    <h1>Admin Users</h1>
    <?php if (!empty($admins)): ?>
        <ul>
            <?php foreach ($admins as $admin): ?>
                <li>ID: <?php echo htmlspecialchars($admin['id']); ?>, Name: <?php echo htmlspecialchars($admin['name']); ?>,
                    Email: <?php echo htmlspecialchars($admin['email']); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No admin users found.</p>
    <?php endif; ?>
</body>

</html>