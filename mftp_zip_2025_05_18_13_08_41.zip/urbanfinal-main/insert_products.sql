-- Insert products
INSERT INTO products (name, description, price, image_url, category) VALUES
('Cherry Tomato Plant', 'Perfect for rooftop containers and produces sweet, bite-sized tomatoes.', 350.00, 'IDP-2-main/Untitled.jpeg', 'vegetable'),
('Herb Garden Kit', 'Grow your own basil, mint, and cilantro with this complete starter kit.', 650.00, 'IDP-2-main/k.jpeg', 'vegetable'),
('Gardening Tool Set', 'Essential tools for rooftop gardening in a convenient carrying case.', 1200.00, 'IDP-2-main/t.jpeg', 'tools'),
('Organic Fertilizer', 'Nutrient-rich organic fertilizer specially formulated for container plants.', 450.00, 'https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e', 'fertilizer'),
('Rose Bush', 'Beautiful flowering rose bush that thrives in containers.', 550.00, 'https://images.unsplash.com/photo-1596573311809-38b7a6d17e8d', 'flower'),
('Dwarf Mango Tree', 'Compact mango tree variety perfect for rooftop cultivation.', 1500.00, 'https://images.unsplash.com/photo-1623241899289-e9a64d8c4e7a', 'fruit'); 