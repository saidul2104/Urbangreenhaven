<?php

// Handle Q&A deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'delete_question':
                if (isset($_POST['question_id'])) {
                    try {
                        $stmt = $pdo->prepare('DELETE FROM questions WHERE id = ?');
                        $stmt->execute([$_POST['question_id']]);
                        echo json_encode(['success' => true]);
                    } catch (PDOException $e) {
                        echo json_encode(['success' => false, 'message' => 'Error deleting question']);
                    }
                }
                break;

            case 'delete_answer':
                if (isset($_POST['answer_id'])) {
                    try {
                        $stmt = $pdo->prepare('DELETE FROM answers WHERE id = ?');
                        $stmt->execute([$_POST['answer_id']]);
                        echo json_encode(['success' => true]);
                    } catch (PDOException $e) {
                        echo json_encode(['success' => false, 'message' => 'Error deleting answer']);
                    }
                }
                break;
        }
    }
} 